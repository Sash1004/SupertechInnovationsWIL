﻿using Microsoft.AspNetCore.Identity;

namespace WebApplication6.Areas.Data
{
    public class AppUser : IdentityUser
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
